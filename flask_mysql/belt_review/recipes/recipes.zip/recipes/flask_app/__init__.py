from flask import Flask

app = Flask(__name__)
app.secret_key = "ce3c4e114bd257476bdc4bf66d553fdc0bc504ad8f3429a59d1f0cf2c22ee179"
