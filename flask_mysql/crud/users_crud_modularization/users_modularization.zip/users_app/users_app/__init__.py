from flask import Flask

app = Flask(__name__)
app.secret_key = "ba8cf0499fc34404163a0ed75c4163825c9b85c3fa2f951c1ca3c31b5674520f"
